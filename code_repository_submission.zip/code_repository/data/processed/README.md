# data/processed — lightweight subset

This folder contains only the **lightweight outputs** required to inspect the
key results and to run the figure/table-generation scripts for the smaller
cohorts. The ~18 GB of raw data and the bulk-expression matrices are **not**
bundled (see repository `.gitignore`); regenerate them with the pipeline or
download from the public repositories listed below.

## Included here
- `peroxisome_gene_set.json` — 131-gene peroxisome-related gene (PRG) set
- `TCGA_PRS_coefficients.csv` — 10-gene peroxisome-related prognostic signature (PRS) coefficients
- `*_clinical.csv`, `*_validation_surv.csv`, `*_risk.csv` — clinical / survival tables for every cohort
- `TCGA_*` — TCGA-LIHC derived tables (mutations, TMB, DEG, PXS, ML CV C-index, clinical with PRS/PXS)
- `sc/` — single-cell cell-type annotations, CNV, cell–cell communication, pseudotime (all five sc cohorts)
- association outputs: `immune_infiltration_PRS.csv`, `mutation_PRS.csv`, `drug_sensitivity_PRS.csv`, `signature_comparison.csv`, `GSEA_PRS_high_vs_low.csv`

## External data (not bundled — fetch before running the full pipeline)
| Source | Accession | Path used |
|---|---|---|
| GEO | GSE149614, GSE151530, GSE125449, GSE146115, GSE98638 (scRNA-seq) | data/raw/ |
| GEO | GSE14520, GSE76427, GSE116174, GSE10186, GSE25097, GSE36376, GSE54236, GSE87630 (bulk) | data/raw/ |
| Broad GDAC Firehose | TCGA-LIHC (2016_01_28) | data/raw/ |
| ICGC Data Portal | ICGC-LIRI-JP (release 28) | data/raw/ |
| GDSC1 | oncoPredict OSF mirror | data/raw/ |
| MSigDB | Hallmark / C2 (license required) | data/genesets/ |
