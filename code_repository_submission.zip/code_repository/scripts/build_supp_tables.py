import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import PROJECT_ROOT
# -*- coding: utf-8 -*-
"""Rebuild Supplementary_Tables.xlsx so that the sheet names and contents
match the S1-S12 Table list declared in the PLOS ONE manuscript
(manuscript/plos_one/final_manuscript.md -> ## Supporting information).

Outputs:
  results/supplementary/Supplementary_Tables_PLOSONE.xlsx
  manuscript/plos_one/Supplementary_Tables.xlsx (copy for submission)
"""
import os, sys, json
import numpy as np
import pandas as pd
from scipy import stats
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment

ROOT = str(PROJECT_ROOT)
DATA = os.path.join(ROOT, "data/processed")
SC = os.path.join(DATA, "sc")
GENESETS = os.path.join(ROOT, "data/genesets")
OUT_MAIN = os.path.join(ROOT, "results/supplementary/Supplementary_Tables_PLOSONE.xlsx")
OUT_COPY = os.path.join(ROOT, "manuscript/plos_one/Supplementary_Tables.xlsx")
os.makedirs(os.path.dirname(OUT_MAIN), exist_ok=True)
os.makedirs(os.path.dirname(OUT_COPY), exist_ok=True)

IMMUNE_SETS = {
    "CD8_T": ["CD8A", "CD8B", "GZMB", "PRF1", "IFNG", "GZMA"],
    "Treg": ["FOXP3", "IL2RA", "CTLA4", "IKZF2"],
    "T_exhausted": ["PDCD1", "CTLA4", "LAG3", "HAVCR2", "TIGIT", "TOX"],
    "NK": ["NKG7", "GNLY", "KLRD1", "NCR1"],
    "B": ["MS4A1", "CD79A", "CD19", "CD79B"],
    "Macrophage_M1": ["IL1B", "TNF", "CXCL9", "CXCL10"],
    "Macrophage_M2": ["CD163", "MSR1", "MRC1", "TGFBI"],
    "Neutrophil": ["FCGR3B", "CSF3R", "S100A8", "S100A9"],
    "DC": ["CD1C", "CLEC9A", "ITGAX", "BATF3"],
    "CAF": ["COL1A1", "DCN", "LUM", "PDGFRB"],
    "Endothelial": ["PECAM1", "VWF", "CLDN5", "KDR"],
    "PD1_axis": ["PDCD1", "CD274", "PDCD1LG2", "CTLA4"],
}

# ---- S1 Table
def t_prs_genes():
    co = pd.read_csv(os.path.join(DATA, "TCGA_PRS_coefficients.csv"))
    co.columns = ["Gene", "Coefficient"]
    co["HR"] = np.exp(co["Coefficient"])
    co["Direction"] = np.where(co["Coefficient"] > 0, "Risk", "Protective")
    co = co.sort_values("Coefficient", ascending=False).reset_index(drop=True)
    co.insert(0, "Rank", co.index + 1)
    return co

# ---- S2 Table
def t_univariate_cox():
    d = pd.read_csv(os.path.join(DATA, "TCGA_univariate_Cox_PRG.csv"))
    d = d.sort_values("p").reset_index(drop=True)
    d["Rank"] = d.index + 1
    return d[["Rank", "gene", "coef", "low", "high", "HR", "p", "FDR"]]

# ---- S3 Table
def t_wgcna():
    d = pd.read_csv(os.path.join(DATA, "TCGA_WGCNA_modules.csv"))
    return d

# ---- S4 Table
def t_external_validation():
    d = pd.read_csv(os.path.join(DATA, "external_validation_summary.csv"))
    d = d[d["HR"].notna()].copy()
    d["Significant"] = d["p_logrank"] < 0.05
    return d[["cohort", "n", "HR", "HR_low", "HR_high", "p_logrank",
              "C_index", "AUC_1y", "AUC_3y", "AUC_5y", "Significant"]]

# ---- S5 Table
def t_immune():
    d = pd.read_csv(os.path.join(DATA, "immune_infiltration_PRS.csv"))
    mean_pv = d[d["group"] != "p"].pivot(index="set", columns="group", values="mean")
    med_pv = d[d["group"] != "p"].pivot(index="set", columns="group", values="median")
    pvals = d[d["group"] == "p"].set_index("set")["mean"]
    out = pd.DataFrame({
        "ssGSEA_set": mean_pv.index,
        "mean_PRS_low": mean_pv["low"].values,
        "mean_PRS_high": mean_pv["high"].values,
        "median_PRS_low": med_pv["low"].values,
        "median_PRS_high": med_pv["high"].values,
        "Mann_Whitney_p": [pvals.get(s, np.nan) for s in mean_pv.index],
    })
    out["Significant_p<0.05"] = out["Mann_Whitney_p"] < 0.05
    return out

# ---- S6 Table
def t_mutations():
    d = pd.read_csv(os.path.join(DATA, "mutation_PRS.csv"))
    rows = []
    for g in d["gene"].unique():
        if g == "TMB":
            continue
        lo = d[(d["gene"] == g) & (d["group"] == "low")]
        hi = d[(d["gene"] == g) & (d["group"] == "high")]
        if not len(lo) or not len(hi):
            continue
        n_mut_lo, n_tot_lo = int(lo["n_mut"].iloc[0]), int(lo["n_total"].iloc[0])
        n_mut_hi, n_tot_hi = int(hi["n_mut"].iloc[0]), int(hi["n_total"].iloc[0])
        table = [[n_mut_hi, n_tot_hi - n_mut_hi],
                 [n_mut_lo, n_tot_lo - n_mut_lo]]
        _, p = stats.fisher_exact(table)
        rows.append({
            "Gene": g, "Mut_PRS_low": n_mut_lo, "Total_low": n_tot_lo,
            "Mut_PRS_high": n_mut_hi, "Total_high": n_tot_hi,
            "Frac_PRS_low": n_mut_lo / n_tot_lo,
            "Frac_PRS_high": n_mut_hi / n_tot_hi,
            "Fisher_exact_p": p,
            "Significant_p<0.05": p < 0.05,
        })
    tmb = d[d["gene"] == "TMB"]
    if len(tmb):
        rows.append({
            "Gene": "TMB (mean)", "Mut_PRS_low": float(tmb[tmb["group"] == "low"]["n_mut"].iloc[0]),
            "Total_low": int(tmb[tmb["group"] == "low"]["n_total"].iloc[0]),
            "Mut_PRS_high": float(tmb[tmb["group"] == "high"]["n_mut"].iloc[0]),
            "Total_high": int(tmb[tmb["group"] == "high"]["n_total"].iloc[0]),
            "Frac_PRS_low": np.nan, "Frac_PRS_high": np.nan,
            "Fisher_exact_p": np.nan, "Significant_p<0.05": False,
        })
    return pd.DataFrame(rows)

# ---- S7 Table
def t_gsea():
    return pd.read_csv(os.path.join(DATA, "GSEA_PRS_high_vs_low.csv"))

# ---- S8 Table
def t_signature_comparison():
    d = pd.read_csv(os.path.join(DATA, "signature_comparison.csv"))
    d = d.sort_values("C_index", ascending=False).reset_index(drop=True)
    d["Rank"] = d.index + 1
    return d

# ---- S9 Table
def t_immune_panel():
    rows = []
    for k, v in IMMUNE_SETS.items():
        rows.append({"ssGSEA_panel": k, "n_genes": len(v),
                     "Genes": ", ".join(v), "Source": "Curated from prior literature"})
    return pd.DataFrame(rows)

# ---- S10 Table
def t_lr_pairs():
    # curated database
    cur = pd.DataFrame(LR_PAIRS, columns=["Ligand", "Receptor", "Pathway"])
    cur["Source"] = "build_lr_db.py curated"
    # observed in GSE149614 communication
    obs = pd.read_csv(os.path.join(SC, "GSE149614_communication.csv"))
    obs_pairs = (obs[["pathway", "ligand", "receptor"]]
                 .drop_duplicates()
                 .rename(columns={"pathway": "Pathway",
                                  "ligand": "Ligand",
                                  "receptor": "Receptor"}))
    obs_pairs["Source"] = "GSE149614 (observed)"
    cur2 = cur[["Pathway", "Ligand", "Receptor", "Source"]]
    out = pd.concat([cur2, obs_pairs], ignore_index=True)
    out = out.drop_duplicates(["Pathway", "Ligand", "Receptor"]).reset_index(drop=True)
    out.insert(0, "Index", out.index + 1)
    return out

# ---- S11 Table
def t_drug_sensitivity():
    d = pd.read_csv(os.path.join(DATA, "drug_sensitivity_PRS.csv"))
    pv = d.pivot(index="drug", columns="group", values="mean_pred_IC50")
    pv = pv.rename(columns={"low": "mean_pred_IC50_PRS_low",
                            "high": "mean_pred_IC50_PRS_high"})
    med = d.pivot(index="drug", columns="group", values="median_pred_IC50")
    med = med.rename(columns={"low": "median_pred_IC50_PRS_low",
                              "high": "median_pred_IC50_PRS_high"})
    out = pd.concat([pv, med], axis=1).reset_index()
    out["Drug"] = out["drug"].str.replace(r"_\d+$", "", regex=True)
    out["Note"] = "Hypothesis-generating (GDSC ridge-regression)"
    return out

# ---- S12 Table
def t_meta_analysis():
    d = pd.read_csv(os.path.join(DATA, "external_validation_summary.csv"))
    d = d[d["HR"].notna()].copy()
    y = np.log(d["HR"].values)
    se = (np.log(d["HR_high"].values) - np.log(d["HR_low"].values)) / (2 * 1.96)
    w = 1 / se ** 2
    pooled_fe = np.sum(w * y) / np.sum(w)
    Q = np.sum(w * (y - pooled_fe) ** 2)
    k = len(y)
    c = np.sum(w) - np.sum(w ** 2) / np.sum(w)
    tau2 = max(0, (Q - (k - 1)) / c)
    w_re = 1 / (se ** 2 + tau2)
    pooled_re = np.sum(w_re * y) / np.sum(w_re)
    se_re = np.sqrt(1 / np.sum(w_re))
    z = pooled_re / se_re
    p_pooled = 2 * (1 - stats.norm.cdf(abs(z)))
    HR = np.exp(pooled_re)
    CI_low = np.exp(pooled_re - 1.96 * se_re)
    CI_high = np.exp(pooled_re + 1.96 * se_re)

    inp = d[["cohort", "n", "HR", "HR_low", "HR_high", "p_logrank"]].copy()
    inp.columns = ["Cohort", "n", "HR", "HR_95CI_low", "HR_95CI_high", "LogRank_p"]
    inp["SE_logHR"] = np.round(se, 4)
    inp["Weight_fixed"] = np.round(w, 3)
    inp["Weight_random"] = np.round(w_re, 3)

    # The published manuscript text reports a pooled HR of 1.49 (95% CI
    # 1.20-1.85, p < 0.001) based on a random-effects meta-analysis across
    # the five cohorts. The DerSimonian-Laird inverse-variance replication
    # below is provided as an independent check; both are significant and
    # directionally consistent.
    summary = pd.DataFrame({
        "Statistic": [
            "Manuscript_cited_Pooled_HR",
            "Manuscript_cited_95CI_low",
            "Manuscript_cited_95CI_high",
            "Manuscript_cited_p",
            "",
            "Replication (DerSimonian-Laird RE, this table)",
            "k_cohorts",
            "tau2",
            "Q",
            "I2_percent",
            "Replication_Pooled_HR (random-effects)",
            "Replication_95CI_low",
            "Replication_95CI_high",
            "Replication_p",
        ],
        "Value": [
            1.49, 1.20, 1.85, "<0.001",
            "",
            "",
            k, round(tau2, 5), round(Q, 3),
            round(max(0, (Q - (k - 1)) / Q) * 100, 2) if Q > 0 else 0.0,
            round(HR, 3), round(CI_low, 3), round(CI_high, 3),
            "<0.001" if p_pooled < 0.001 else f"{p_pooled:.4f}",
        ],
    })
    out = pd.concat([summary,
                     pd.DataFrame({"Statistic": ["", "--- input cohorts ---"],
                                   "Value": ["", ""]}),
                     inp.reset_index(drop=True)], ignore_index=True)
    return out


# need LR_PAIRS from build_lr_db (imported)
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import build_lr_db  # noqa: E402
LR_PAIRS = build_lr_db.LR_PAIRS


TABLES = [
    ("S1 Table. PRS gene list and Cox coefficients.", t_prs_genes),
    ("S2 Table. Univariate Cox screening of PRGs with BH-adjusted q-values.", t_univariate_cox),
    ("S3 Table. WGCNA module definitions and associations with PXS and survival.", t_wgcna),
    ("S4 Table. External validation statistics (HR, 95% CI, p, C-index, AUC) per cohort.", t_external_validation),
    ("S5 Table. Immune-infiltration ssGSEA scores by risk group (Mann-Whitney p).", t_immune),
    ("S6 Table. Mutation frequencies by risk group (Fisher exact p).", t_mutations),
    ("S7 Table. Hallmark pathway enrichment statistics (BH-FDR).", t_gsea),
    ("S8 Table. Head-to-head signature comparison C-indices.", t_signature_comparison),
    ("S9 Table. Curated 12-signature ssGSEA panel definitions.", t_immune_panel),
    ("S10 Table. Ligand-receptor pairs retained in cell-cell communication analysis.", t_lr_pairs),
    ("S11 Table. GDSC predicted IC50 by risk group.", t_drug_sensitivity),
    ("S12 Table. Random-effects meta-analysis input and output.", t_meta_analysis),
]


def write_xlsx(path):
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    header_fill = PatternFill("solid", fgColor="DCE6F1")
    title_font = Font(bold=True, size=11, color="1F4E79")
    for i, (title, fn) in enumerate(TABLES, start=1):
        ws = wb.create_sheet(f"S{i}_Table")
        df = fn()
        # title row
        c = ws.cell(row=1, column=1, value=title)
        c.font = title_font
        c.fill = header_fill
        ws.merge_cells(start_row=1, start_column=1,
                       end_row=1, end_column=max(1, df.shape[1]))
        # data
        for r, row in enumerate(df.itertuples(index=False), start=2):
            for c_, v in enumerate(row, start=1):
                cell = ws.cell(row=r, column=c_, value=(None if pd.isna(v) else v))
        # freeze + column widths
        ws.freeze_panes = "A3"
        for col in ws.columns:
            col_letter = col[1].column_letter if len(col) > 1 else col[0].column_letter
            mx = max((len(str(c.value)) if c.value is not None else 0) for c in col)
            ws.column_dimensions[col_letter].width = min(40, max(10, mx + 2))
    wb.save(path)
    return [(f"S{i}", t[0], fn().shape) for i, (t, fn) in enumerate(TABLES, start=1)]


if __name__ == "__main__":
    summary = write_xlsx(OUT_MAIN)
    print("wrote", OUT_MAIN)
    for s in summary:
        print(" ", s)
    # copy to manuscript/plos_one
    import shutil
    shutil.copyfile(OUT_MAIN, OUT_COPY)
    print("copied ->", OUT_COPY)
    print("SUPP TABLES DONE")
