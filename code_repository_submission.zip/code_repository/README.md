# Analysis code for: A peroxisome-related prognostic signature defines an immune-silent malignant cell state in hepatocellular carcinoma

> **Status:** Ready for upload to GitHub + Zenodo. Replace the `[...]` placeholders
> (author name, manuscript DOI) after acceptance.
> This repository stores the analysis scripts underpinning the findings of the
> manuscript above (PLOS ONE, submitted 2026).

## Overview

This repository contains the reproducible code for:

- Single-cell RNA-seq processing of five HCC datasets (**76,762 cells after QC**)
- Construction and 10-fold cross-validated evaluation of a **ten-gene peroxisome-related prognostic signature (PRS)** — TCGA C-index **0.761**, cross-validated **0.727**
- External bulk validation across five independent cohorts (meta pooled HR **1.49**, 95% CI 1.20–1.85)
- Immune, mutational, and drug-sensitivity association analyses
- Figure generation (main Figs 1–8) and Supplementary Figs/Tables S1–S12

All data used are publicly available; see **Data availability** below.

## Repository structure

```
code_repository/
├── README.md
├── requirements.txt          # pinned dependency versions
├── LICENSE                  # MIT
├── .gitignore
├── config.py                # paths, random seed, cohort accessions
├── scripts/                 # all analysis / figure / table scripts (flat)
│   ├── figstyle.py          # shared plotting style (label_axes / sig_bracket / save)
│   ├── pubs.py              # PubMed helper (citation formatting)
│   ├── core.py              # shared utilities + ML framework
│   ├── fig_bulk.py          # Figs 2–5, 8 (bulk + validation)
│   ├── fig_sc.py            # Figs 1, 6, 7 (single-cell)
│   ├── build_prs.py         # 10-gene PRS construction
│   ├── build_prg.py         # 131-gene PRG set + scoring
│   ├── build_supp_figures.py  # S1–S12 supplementary figures
│   ├── build_supp_tables.py   # S1–S12 supplementary tables
│   ├── sc_preprocess.py / sc_analysis.py / sc_annotate.py  # single-cell pipeline
│   ├── analysis_bulk2.py / analysis_tcga.py  # bulk association + TCGA
│   ├── build_geo.py / build_tcga.py / build_icgc.py / dl.py  # data acquisition
│   └── fetch_*.py / parse_geo.py / probe_geo.py / gpl_dl_extract.py / ...  # downloaders & parsers
└── data/
    └── processed/           # lightweight subset only (see data/processed/README.md)
```

> Scripts are kept flat so that the intra-package imports
> (`import figstyle`, `import core`, `from config import PROJECT_ROOT`, …) resolve
> without modification. Hardcoded project paths have been redirected through
> `config.PROJECT_ROOT`, so the repo is relocatable.

## Environment

- Python **3.13.12** (developed and tested)
- Install dependencies:

```bash
pip install -r requirements.txt
```

## Data availability

Raw data were downloaded from public repositories. **No new data were generated.**
The ~18 GB of raw data and bulk-expression matrices are **not** included in this
archive; download them from the accessions below (also listed in
`data/processed/README.md`) and place under `data/raw/`, or re-run the
acquisition scripts (`build_geo.py`, `build_tcga.py`, `build_icgc.py`,
`fetch_*.py`). MSigDB gene sets require a (free) license and go in
`data/genesets/`.

| Dataset | Accession | Use |
|---|---|---|
| scRNA-seq | GSE149614, GSE151530, GSE125449, GSE146115, GSE98638 | single-cell atlas |
| Bulk RNA-seq | GSE14520, GSE76427, GSE116174, GSE10186, GSE25097, GSE36376, GSE54236, GSE87630 | validation |
| TCGA-LIHC | Broad GDAC Firehose (2016_01_28) | training + KM |
| ICGC-LIRI-JP | ICGC Data Portal (release 28) | validation |
| GDSC1 | oncoPredict OSF mirror | drug sensitivity |

A lightweight subset of processed outputs (clinical/risk tables, PRS
coefficients, the PRG set, single-cell annotations) **is** bundled under
`data/processed/` so that the smaller-cohort figures/tables can be reproduced
without re-downloading the full matrices.

## How to reproduce

```bash
# 0. (optional) fetch raw data — or place it manually under data/raw/
python scripts/build_geo.py
python scripts/build_tcga.py
python scripts/build_icgc.py

# 1. Single-cell processing + Figs 1, 6, 7
python scripts/sc_preprocess.py
python scripts/sc_analysis.py
python scripts/sc_annotate.py
python scripts/fig_sc.py

# 2. Build the 10-gene PRS (10-fold CV) -> data/processed/TCGA_PRS_coefficients.csv
python scripts/build_prs.py

# 3. Bulk association + external validation + Figs 2-5, 8
python scripts/analysis_bulk2.py
python scripts/analysis_tcga.py
python scripts/fig_bulk.py

# 4. Supplementary figures & tables (S1-S12)
python scripts/build_supp_figures.py
python scripts/build_supp_tables.py
```

Expected runtime: single-cell + bulk processing dominates (~hours on a multicore
node); the PRS/figure/table steps are minutes. Adjust `config.SEED` only if you
need to re-randomise cross-validation folds.

## The PRS (ten genes, TCGA-derived coefficients)

| Gene | Coefficient | Direction |
|---|---|---|
| IDH1 | +0.467 | risk |
| UBE2D2 | +0.383 | risk |
| AOC1 | +0.342 | risk |
| SLC25A17 | +0.204 | risk |
| UBB | -0.174 | protective |
| CRAT | -0.189 | protective |
| MTARC2 | -0.247 | protective |
| ABCD2 | -0.282 | protective |
| ACOXL | -0.333 | protective |
| PECR | -0.433 | protective |

Full coefficients are in `data/processed/TCGA_PRS_coefficients.csv` and
manuscript S1 Table. The 131-gene PRG set is `data/processed/peroxisome_gene_set.json`.

## License

Code is released under the MIT license (see `LICENSE`). PLOS ONE requires
author-generated code to be made available without restrictions; MIT satisfies
this.

## Citation

If you use this code, please cite:

> [Author list]. A peroxisome-related prognostic signature defines an immune-silent malignant cell state in hepatocellular carcinoma. *PLOS ONE* (2026). DOI: [10.1371/journal.pone.XXXXXXX]

Zenodo archive (upon acceptance): [https://doi.org/10.5281/zenodo.XXXXXXX]
